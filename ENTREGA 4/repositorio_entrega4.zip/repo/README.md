# Cafeterías de especialidad, valor del suelo y valorización en Bogotá

Trabajo de campo (encuesta de percepción, 8 de noviembre de 2026) – Haciendo Economía 2026-2, Universidad del Rosario.

## Estructura
- `informe/` – informe de trabajo de campo (Entrega 4).
- `datos/cruda/` – base cruda **anonimizada** (68 registros).
- `datos/limpia/` – base limpia, válida y georreferenciada (57 registros).
- `documentacion/` – diccionario de variables y texto de consentimiento (agregar aquí el cuestionario en PDF).
- `evidencia/` – fotografías y video con autorización (pendiente).
- `scripts/limpieza_analisis.py` – genera las bases publicadas y las frecuencias a partir de la base RAW.
- `resultados/` – tablas de frecuencias.

## Reproducir
```
pip install pandas openpyxl
python scripts/limpieza_analisis.py Base_Datos_RAW_Entrega4.xlsx
```
La base RAW original no se publica porque contiene nombres de personas.
